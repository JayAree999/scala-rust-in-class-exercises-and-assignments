mod charfreq;
mod linsearch;
mod numprimes;
mod pangrindrome;
mod perfect;
mod roman;
use chashmap::CHashMap;
use rayon::iter::{IntoParallelRefIterator, ParallelIterator};
use std::collections::HashMap;
fn main() {
    
    let data: Vec<String> = vec!["banana".to_string()];

}
